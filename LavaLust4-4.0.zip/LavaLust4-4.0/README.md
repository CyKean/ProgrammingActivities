## LavaLust 4 Development
<p align="center">
    <img width="200" height="300" src="https://raw.githubusercontent.com/ronmarasigan/LavaLust-Docs/master/assets/images/logo1.png">
</p>
    This repository is now inactive. Please proceed to [Lavalust Official Repository](https://github.com/ronmarasigan/LavaLust). The current active branch for LavaLust Version 4 is dev-v4.
